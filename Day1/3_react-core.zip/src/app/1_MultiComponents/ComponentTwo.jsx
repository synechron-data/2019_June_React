import React, { Component } from 'react';

class ComponentTwo extends Component {
    render() {
        return (
            <div>
                <h2 className="text-success">Hello from Component Two</h2>
            </div>
        );
    }
}

export default ComponentTwo;