import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        return (
            <div>
                <h2 className="text-info">Hello from Component One</h2>
            </div>
        );
    }
}

export default ComponentOne;