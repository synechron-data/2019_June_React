import React, { Component } from 'react';
// import ComponentOne from './1_MultiComponents/ComponentOne';
// import ComponentTwo from './1_MultiComponents/ComponentTwo';

// import ComponentOne from './2_ComponentWithCSS/CompOne/ComponentOne';
// import ComponentTwo from './2_ComponentWithCSS/CompTwo/ComponentTwo';

import ComponentOne from './3_CSSModules/CompOne/ComponentOne'
import ComponentTwo from './3_CSSModules/CompTwo/ComponentTwo';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <h1>This is Root Component</h1>
                <ComponentOne/>
                <ComponentTwo/>
            </div>
        );
    }
}

export default RootComponent;