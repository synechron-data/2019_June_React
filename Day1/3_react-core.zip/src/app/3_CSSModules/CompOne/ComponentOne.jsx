import React from 'react';

import styles from './ComponentOne.module.css';

const ComponentOne = () => (
    <div>
        <h2 className="text-info">Hello from Component One</h2>
        <h2 className={styles.card1}>Hello from Component One</h2>
    </div>
);

export default ComponentOne;