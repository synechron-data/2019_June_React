import React from 'react';

import styles from './ComponentTwo.module.css';

const ComponentTwo = () => (
    <div>
        <h2 className="text-success">Hello from Component Two</h2>
        <h2 className={styles.card1}>Hello from Component Two</h2>
    </div>
);

export default ComponentTwo;