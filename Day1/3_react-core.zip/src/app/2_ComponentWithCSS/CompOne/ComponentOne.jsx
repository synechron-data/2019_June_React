import React from 'react';

// const ComponentOne = () => {
//     const card1 = {
//         margin: '1em',
//         paddingLeft: 0,
//         border: '2px solid blue'
//     };

//     return (
//         <div>
//             <h2 style={card1} className="text-info">Hello from Component One</h2>
//         </div>
//     );
// }

import './ComponentOne.css';

const ComponentOne = () => (
    <div>
        <h2 className="card1 text-info">Hello from Component One</h2>
    </div>
);

export default ComponentOne;