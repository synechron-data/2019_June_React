import React from 'react';

// const ComponentTwo = () => {
//     const card2 = {
//         margin: '1em',
//         paddingLeft: 0,
//         border: '2px dashed green'
//     };

//     return (
//         <div>
//             <h2 style={card2} className="text-success">Hello from Component Two</h2>
//         </div>
//     );
// }

import './ComponentTwo.css';

const ComponentTwo = () => (
    <div>
        <h2 className="card2 text-success">Hello from Component Two</h2>
    </div>
);

export default ComponentTwo;