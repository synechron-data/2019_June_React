import React from 'react';
import ReactDOM from 'react-dom';
import RootComponent from './app/RootComponent';

// -------------------------------- Including Bootstrap 3
// // npm install --sabe bootstrap@3 jquery
// import $ from 'jquery';
// import 'bootstrap/dist/css/bootstrap.css';

// window.$ = $;
// window.jQuery = $;
// global.jQuery = $;

// const bootstrap = require('bootstrap');

// ----------------------------------- Including Bootstrap 4
// npm install --save bootstrap jquery popper.js
// npm install --save-dev node-sass

import $ from 'jquery';
import 'bootstrap/scss/bootstrap.scss';

window.$ = $;
window.jQuery = $;
global.jQuery = $;

const bootstrap = require('bootstrap');


ReactDOM.render(<RootComponent />, document.getElementById("root"));