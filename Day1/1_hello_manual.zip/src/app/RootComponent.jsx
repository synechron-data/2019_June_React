import React, { Component } from 'react';
import Hello from './HelloComponent';
import Hello2 from './Hello2.Component';

class Root extends Component {
    render() {
        return (
            <React.Fragment>
                <Hello />
                <Hello2 />
            </React.Fragment>
        );
    }
}

export default Root;