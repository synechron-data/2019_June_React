import React, { Component } from 'react';

class Hello2 extends Component {
    render() {
        return (
            <h1 className="abc">Hi World!</h1>
        );
    }
}

export default Hello2;