import React from 'react';
import ReactDOM from 'react-dom';
import Root from './app/RootComponent';
import Hello from './app/HelloComponent';
import Hello2 from './app/Hello2.Component';

var r1 = ReactDOM.render(<Root/>, document.getElementById("container"));
console.log(r1);

var r2 = ReactDOM.render(<Hello/>, document.getElementById("container1"));
console.log(r2);

var r3 = ReactDOM.render(<Hello2/>, document.getElementById("container2"));
console.log(r3);
