import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as productActions from '../../actions/productActions';
import ProductListComponent from '../../components/products/ProductListComponent';
import AddProductButton from '../../components/products/AddProductButton';

class ProductsContainer extends Component {
    render() {
        console.log(this.props.products);
        return (
            <React.Fragment>
                <AddProductButton/>
                <br/>
                <br/>
                <ProductListComponent products={this.props.products} />
            </React.Fragment>
        );
    }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => dispatch(productActions.loadProducts())
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);