import * as actionTypes from './actionTypes';
import { productAPI } from '../services/product.service';

function loadProductsSuccess(products) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: products
    }
}

function insertProductSuccess(product) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: product
    }
}

function updateProductSuccess(product) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: product
    }
}

export function loadProducts() {
    return function(dispatch){
        productAPI.getAllProducts().then((products)=>{
            dispatch(loadProductsSuccess(products));
        }, (eMsg) => {
            console.error(eMsg);
        })
    }
}

export function insertProduct(product) {
    return function(dispatch){
        productAPI.insertProduct(product).then((insertedProduct)=>{
            dispatch(insertProductSuccess(insertedProduct));
        }, (eMsg) => {
            console.error(eMsg);
        })
    }
}

export function updateProduct(product) {
    return function(dispatch){
        productAPI.updateProduct(product).then((updatedProduct)=>{
            dispatch(updateProductSuccess(updatedProduct));
        }, (eMsg) => {
            console.error(eMsg);
        })
    }
}