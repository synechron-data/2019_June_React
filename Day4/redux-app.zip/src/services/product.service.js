const url = 'http://localhost:8000/products';

export const productAPI = {
    getAllProducts: function () {
        var promise = new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then((data) => {
                    resolve(data);
                }, (err) => {
                    reject("Parsing Error...");
                })
            }, (err) => {
                reject("Communication Error...");
            })
        });
        return promise;
    }, 

    insertProduct: function (p) {
        const request = new Request(url, {
            method: "POST",
            headers: new Headers({
                "Content-Type": "application/json"
            }),
            body: JSON.stringify(p)
        });

        return fetch(request).then(res => {
            return res.json()
        }).catch(error => {
            return error;
        });
    },

    updateProduct: function (p) {
        const request = new Request(url + "/" + p.id, {
            method: "PUT",
            headers: new Headers({
                "Content-Type": "application/json"
            }),
            body: JSON.stringify(p)
        });

        return fetch(request).then(res => {
            return res.json()
        }).catch(error => {
            return error;
        });
    },

    deleteProduct: function (p) {
        const request = new Request(url + "/" + p.id, {
            method: "DELETE"
        });

        return fetch(request).then(res => {
            return res.json();
        }).catch(error => {
            return error;
        });
    }
}