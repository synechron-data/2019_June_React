import React, { Component } from 'react';
import DataTable from './common/DataTable';
import ajaxHelper from './services/ajaxHelper.service';

class PropForwardingComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading data, please wait..." };
    }

    render() {
        return (
            <div>
                <h3 className="text-warning">{this.state.message}</h3>
                <ChildOneComponent data={this.state.posts}/>
            </div>
        );
    }

    componentDidMount() {
        var promise = ajaxHelper.getAllPosts();
        promise.then((data) => {
            this.setState({ posts: [...data], message: "" });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        })
    }

}

class ChildOneComponent extends Component {
    render() {
        return (
            <div>
                <ChildTwoComponent dataArr={this.props.data}/>
            </div>
        );
    }
}

class ChildTwoComponent extends Component {
    render() {
        return (
            <div>
                <DataTable items={this.props.dataArr}>
                    <h4 className="text-success">Posts Table</h4>
                </DataTable>
            </div>
        );
    }
}

export default PropForwardingComponent;