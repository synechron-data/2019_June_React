const ajaxHelper = {
    getAllPosts: function () {
        var promise = new Promise((resolve, reject) => {
            fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
                // console.log(response);
                response.json().then((data) => {
                    resolve(data);
                }, (err) => {
                    reject("Parsing Error...");
                })
            }, (err) => {
                reject("Communication Error...");
            })
        });
        return promise;
    }
};

export default ajaxHelper;