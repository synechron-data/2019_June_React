/* eslint-disable */
import React from 'react';
import Assignment from './1_Assignment';
import PropTypeRoot from './2_PropTypes';
import ErrorHandler from './common/ErrorHandler';
import Parent from './3_LifeCycleMethods';
import AjaxComponent from './4_AjaxAndComponent';
import PropForwardingComponent from './5_PropForwarding';
import ParentComponent from './6_ContextAPI';

const RootComponent = () => {
    return (
        <div className="container">
            <ErrorHandler>
                {/* <Assignment /> */}
                {/* <PropTypeRoot /> */}
                {/* <Parent/> */}
                {/* <AjaxComponent /> */}
                {/* <PropForwardingComponent/> */}
                <ParentComponent />
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;