const url = "http://localhost:8000/api/authenticate";

export const authenticator = {
    isAuthenticated: false,
    login: function (uname, pwd, loginSuccess, loginFailed) {
        var data = `username=${uname}&password=${pwd}`;

        let fData = {
            method: 'POST',
            headers: {
                "content-type": "application/x-www-form-urlencoded"
            },
            body: data
        };

        fetch(url, fData).then((res) => {
            res.json().then((data) => {
                if (data.success) {
                    window.sessionStorage.setItem("tk", data.token);
                    this.isAuthenticated = data.success;
                    loginSuccess();
                } else {
                    loginFailed(data.message);
                }
            })
        })
    },
    getToken: function () {
        return window.sessionStorage.getItem("tk");
    },

    logout: function () {
        window.sessionStorage.clear();
        this.isAuthenticated = false;
    }
};