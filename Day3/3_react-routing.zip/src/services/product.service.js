import { authenticator } from "./authenticator.service";

const url = 'http://localhost:8000/api/products';

export const productAPI = {
    getAllProducts: function () {
        let fData = {
            method: 'GET',
            headers: {
                "accept": "application/json",
                "x-access-token": authenticator.getToken()
            }
        };

        var promise = new Promise((resolve, reject) => {
            fetch(url, fData).then((response) => {
                response.json().then((data) => {
                    // if (data.success) {
                    //     resolve(data);
                    // } else {
                    //     reject(data.message);
                    // }

                    resolve(data);
                }, (err) => {
                    reject("Parsing Error...");
                })
            }, (err) => {
                reject("Communication Error...");
            })
        });
        return promise;
    }
}