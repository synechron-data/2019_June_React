import React, { Component } from 'react';
import DataTable from "../common/DataTable";
import { productAPI } from '../../services/product.service';

class AdminComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { products: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <div>
                <h1 className="text-info">Admin Component</h1>
                <h4 className="text-success">Welcome, you are an authenticated user.</h4>
                <hr />
                <h3 className="text-warning">{this.state.message}</h3>
                <DataTable items={this.state.products}>
                    <h4 className="text-info">Products Table</h4>
                </DataTable>
            </div>
        );
    }

    componentDidMount() {
        productAPI.getAllProducts().then((data) => {
            console.log(data);
            this.setState({ products: data, message:"" });
        }, (err) => {
            this.setState({ message: err });
        })
    }

}

export default AdminComponent;