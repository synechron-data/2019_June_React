import React, { Component } from 'react';
import { Button, FormGroup, FormControl, ControlLabel, HelpBlock } from "react-bootstrap";
import { authenticator } from '../../services/authenticator.service';
import { Redirect } from 'react-router-dom';

class LoginComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            redirectToReferrer: false,
            message: "",
            username: "",
            password: "",
            formErrors: { username: '', password: '' },
            usernameValid: false,
            passwordValid: false,
            formValid: false
        };
        this.login = this.login.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    login(e) {
        e.preventDefault();
        authenticator.login(this.state.username, this.state.password,
            () => {
                this.setState({ redirectToReferrer: authenticator.isAuthenticated });
            }, (msg) => {
                this.setState({ message: msg });
            })
    }

    handleChange(e) {
        const id = e.target.id;
        const value = e.target.value;
        this.setState({ [id]: value }, () => {
            this.validateField(id, value);
        });
    }

    validateField(fieldName, value) {
        let fieldValidationErrors = this.state.formErrors;
        let usernameValid = this.state.usernameValid;
        let passwordValid = this.state.passwordValid;

        switch (fieldName) {
            case 'username':
                usernameValid = value.length >= 6;
                fieldValidationErrors.username = usernameValid ? '' : 'Username is invalid';
                break;
            case 'password':
                passwordValid = value.length >= 6;
                fieldValidationErrors.password = passwordValid ? '' : 'Password is too short';
                break;
            default:
                break;
        }

        this.setState({
            formErrors: fieldValidationErrors,
            usernameValid: usernameValid,
            passwordValid: passwordValid
        }, this.validateForm);
    }

    validateForm() {
        this.setState({ formValid: this.state.usernameValid && this.state.passwordValid });
    }

    render() {
        const { from } = this.props.location.state || { from: { pathname: "/" } };
        const { redirectToReferrer } = this.state;

        if (redirectToReferrer) {
            return <Redirect to={from} />
        }

        return (
            <div>
                <h1 className="text-info">Login Component</h1>
                {this.state.message ? <h4 className="alert alert-danger">{this.state.message}</h4> : null}
                <div>
                    <form onSubmit={this.login}>
                        <FormGroup controlId="username">
                            <ControlLabel>Username</ControlLabel>
                            <FormControl autoFocus type="text" value={this.state.username}
                                onChange={this.handleChange} />
                            {this.state.formErrors.username ? <HelpBlock>{this.state.formErrors.username}</HelpBlock> : null}
                        </FormGroup>
                        <FormGroup controlId="password">
                            <ControlLabel>Password</ControlLabel>
                            <FormControl type="password" value={this.state.password}
                                onChange={this.handleChange} />
                            {this.state.formErrors.password ? <HelpBlock>{this.state.formErrors.password}</HelpBlock> : null}
                        </FormGroup>
                        <Button block disabled={!this.state.formValid} type="submit">
                            Login
                        </Button>
                    </form>
                </div>
            </div>
        );
    }
}

export default LoginComponent;