/* eslint-disable */
import 'bootstrap/dist/css/bootstrap.css';
import React from 'react';
import ReactDOM from 'react-dom';

import RootComponent from './components/root/RootComponent';

import { BrowserRouter } from "react-router-dom";

import $ from 'jquery';

window.$ = $;
window.jQuery = $;
global.jQuery = $;
const bootstrap = require('bootstrap');

ReactDOM.render(
    <BrowserRouter>
        <RootComponent />
    </BrowserRouter>,
    document.getElementById('root'));