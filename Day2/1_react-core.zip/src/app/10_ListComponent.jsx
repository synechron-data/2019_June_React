import React, { Component } from 'react';

const ListComponent = (props) => {
    var lItems = props.items.map((item, index) => {
        return <li key={index} className="list-group-item">{item.name}</li>;
    });

    // console.log(lItems);

    // var lItems = props.items.map((item, index) => {
    //     return item.name;
    // });

    return (
        <React.Fragment>
            <h2 className="text-info">List Component</h2>
            <ul className="list-group">
                {lItems}
            </ul>
        </React.Fragment>
    );
};

class ListRoot extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
                { id: 1, name: "Manish" },
                { id: 2, name: "Abhijeet" },
                { id: 3, name: "Ramakant" },
                { id: 4, name: "Subodh" },
                { id: 5, name: "Abhishek" }
            ]
        };
    }

    render() {
        return (
            <div>
                <ListComponent items={this.state.employees} />
            </div>
        );
    }
}

export default ListRoot;