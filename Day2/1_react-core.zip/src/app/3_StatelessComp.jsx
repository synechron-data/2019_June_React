/* eslint-disable */

import React from 'react';

// const StatelessComp = (props) => {
//     console.log(props);
//     return (
//         <div>

//         </div>
//     );
// };

// const StatelessComp = ({name, address}) => {
//     console.log(name, address);
//     return (
//         <div>

//         </div>
//     );
// };

var obj = { 
    id: 1, 
    name: "ABC", 
    address: { 
        city: "Pune", 
        zip: 411021 
    } 
};

// var {id, name} = obj;
// var {id, ...allOthers} = obj;
// console.log(id);
// console.log(allOthers);

const StatelessComp = ({ name, ...args }) => {
    console.log(name);
    console.log(args);
    return (
        <div>

        </div>
    );
};

export default StatelessComp;