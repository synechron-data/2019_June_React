import React, { Component } from 'react';

class CompWithState extends Component {
    constructor() {
        super();
        this.state = { name: "Synechron" };
        console.log("Ctor : ", this.state);
    }

    render() {
        console.log("Render : ", this.state);

        return (
            <h2 className="text-success">Hello, {this.state.name}</h2>
        );
    }
}

export default CompWithState;