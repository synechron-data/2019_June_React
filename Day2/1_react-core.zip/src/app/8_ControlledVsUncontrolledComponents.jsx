import React, { Component } from 'react';

class ControlledVsUncontrolledComponents extends Component {
    constructor(props) {
        super(props);
        this.state = { name: "Synechron" };
        this.handleChange = this.handleChange.bind(this);
        this.handleClick = this.handleClick.bind(this);
    }

    handleChange(e) {
        this.setState({ name: e.target.value });
    }

    handleClick(e) {
        this.setState({ name: this.refs.t1.value });
    }

    render() {
        return (
            <div>
                {/* <input type="text" value="Manish" readOnly />
                <br />
                <input type="text" value={this.state.name} readOnly />
                <br />
                <input type="text" defaultValue={this.state.name} /> */}

                {/* <input type="text" value={this.state.name} onChange={this.handleChange} />
                <h3 className="text-info">Name is: {this.state.name}</h3> */}

                <input type="text" defaultValue={this.state.name} ref="t1" />
                <h3 className="text-info">Name is: {this.state.name}</h3>
                <button onClick={this.handleClick}>Click</button>
            </div>
        );
    }
}

export default ControlledVsUncontrolledComponents;