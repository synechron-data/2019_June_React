import React, { Component } from 'react';

class Button extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 0, id: 1 };
    }

    handleClick() {
        // alert("Button was clicked....");
        // console.log("handleClick - ", this);

        // this.state.count += 1;
        this.setState({ count: this.state.count + 1 }, ()=>{
            console.log(this.state.count);
        });
    }

    render() {
        // console.log("render - ", this);
        return (
            <div>
                <h2 className="text-warning">Id: {this.state.id}</h2>
                <h2 className="text-warning">Count: {this.state.count}</h2>
                <button className="btn btn-info" onClick={this.handleClick.bind(this)}>Click Me</button>
            </div>
        );
    }
}

export default Button;