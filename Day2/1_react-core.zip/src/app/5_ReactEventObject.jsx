import React, { Component } from 'react';

class EventComponent extends Component {
    constructor(props) {
        super(props);
        this.handleClick3 = this.handleClick3.bind(this);
    }

    handleClick1(e) {
        console.log("this - ", this);
        console.log("Event - ", e);
        e.preventDefault();
    }

    handleClick2(e) {
        console.log("this - ", this);
        console.log("Event - ", e);
        e.preventDefault();
    }

    handleClick3(e) {
        console.log("this - ", this);
        console.log("Event - ", e);
        e.preventDefault();
    }

    handleClick4(name, e) {
        console.log("Name: ", name);
        console.log("this - ", this);
        console.log("Event - ", e);
        e.preventDefault();
    }

    // Do not do it - Wrong Implementation
    // Will increase Memory Usage
    handleClick8 = (e) => {
        console.log("this - ", this);
        console.log("Event - ", e);
        e.preventDefault();
    }

    render() {
        // console.log(this.handleClick8);
        return (
            <div>
                <a href="http://www.google.com" onClick={this.handleClick1}>Click 1</a>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick2.bind(this)}>Click 2</a>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick3}>Click 3</a>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick4.bind(this, "Manish")}>Click 4</a>
                <br />
                <a href="http://www.google.com" onClick={function (e) {
                    console.log("this - ", this);
                    console.log("Event - ", e);
                    e.preventDefault();
                }}>Click 5 - Anonymous Functions</a>
                <br />
                <a href="http://www.google.com" onClick={(function (e) {
                    console.log("this - ", this);
                    console.log("Event - ", e);
                    e.preventDefault();
                }).bind(this)}>Click 6 - Anonymous Functions</a>
                <br/>
                <a href="http://www.google.com" onClick={(e) => {
                    console.log("this - ", this);
                    console.log("Event - ", e);
                    e.preventDefault();
                }}>Click 7 - Arrow Functions</a>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick8}>Click 8 - Arrow Function in Class</a>
                <br/>
                <a href="http://www.google.com" onClick={(e) => {
                    this.handleClick3(e);   
                }}>Click 9 - Arrow Functions</a>
                <br/>
                <a href="http://www.google.com" onClick={(e) => {
                    this.handleClick4("Abhijeet", e);   
                }}>Click 10 - Arrow Functions</a>
            </div>
        );
    }
}

export default EventComponent;