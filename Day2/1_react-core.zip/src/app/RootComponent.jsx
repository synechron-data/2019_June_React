/* eslint-disable */
import React from 'react';
import CompWithState from './1_CompWithState';
import CompWithProps from './2_CompWithProps';
import StatelessComp from './3_StatelessComp';
import Button from './4_CompWithBehavior';
import EventComponent from './5_ReactEventObject';
import CounterAssignment from './6_CounterAssignment';
import DataFlowAssignment from './7_DataFlowAssignment';
import ControlledVsUncontrolledComponents from './8_ControlledVsUncontrolledComponents';
import CalculatorAssignment from './9_CalculatorAssignment';
import ListRoot from './10_ListComponent';

let address = {
    city: "Pune",
    state: "MH"
};

const RootComponent = () => {
    return (
        <div className="container">
            {/* <CompWithState /> */}
            {/* <CompWithProps name={"Manish"} address={address} test={function(){
                console.log("From Root");
            }}/> */}
            {/* <StatelessComp name={"Manish"} address={address} test={function(){
                console.log("From Root");
            }}/> */}
            {/* <Button/> */}
            {/* <EventComponent/> */}
            {/* <CounterAssignment /> */}
            {/* <DataFlowAssignment/> */}
            {/* <ControlledVsUncontrolledComponents/> */}
            {/* <CalculatorAssignment/> */}
            <ListRoot />
        </div>
    );
};

export default RootComponent;