/* eslint-disable */ 
import React from 'react';
import ReactDOM from 'react-dom';

import RootComponent from './app/RootComponent';

import $ from 'jquery';
import 'bootstrap/dist/css/bootstrap.css';
window.$ = $;
window.jQuery = $;
global.jQuery = $;
const bootstrap = require('bootstrap');

ReactDOM.render(<RootComponent/>, 
    document.getElementById('root'));